﻿namespace _2022_CS_195_ProjectA
{
    partial class Advisor_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Designation_textBox = new TextBox();
            Salary_textBox = new TextBox();
            textBox_Id = new TextBox();
            button_Home = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Yellow;
            label1.Location = new Point(258, 38);
            label1.Name = "label1";
            label1.Size = new Size(251, 50);
            label1.TabIndex = 0;
            label1.Text = "Advisor Page";
            // 
            // Designation_textBox
            // 
            Designation_textBox.BackColor = SystemColors.Info;
            Designation_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Designation_textBox.Location = new Point(258, 205);
            Designation_textBox.Name = "Designation_textBox";
            Designation_textBox.Size = new Size(252, 29);
            Designation_textBox.TabIndex = 1;
            Designation_textBox.Text = "Designation";
            // 
            // Salary_textBox
            // 
            Salary_textBox.BackColor = SystemColors.Info;
            Salary_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Salary_textBox.Location = new Point(429, 139);
            Salary_textBox.Name = "Salary_textBox";
            Salary_textBox.Size = new Size(252, 29);
            Salary_textBox.TabIndex = 2;
            Salary_textBox.Text = "Salary";
            // 
            // textBox_Id
            // 
            textBox_Id.BackColor = SystemColors.Info;
            textBox_Id.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Id.Location = new Point(74, 139);
            textBox_Id.Name = "textBox_Id";
            textBox_Id.Size = new Size(252, 29);
            textBox_Id.TabIndex = 3;
            textBox_Id.Text = "Id";
            // 
            // button_Home
            // 
            button_Home.BackColor = Color.Khaki;
            button_Home.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_Home.ForeColor = SystemColors.ActiveCaptionText;
            button_Home.Location = new Point(339, 322);
            button_Home.Name = "button_Home";
            button_Home.Size = new Size(75, 35);
            button_Home.TabIndex = 4;
            button_Home.Text = "Home";
            button_Home.UseVisualStyleBackColor = false;
            button_Home.Click += Button_Home_Click;
            // 
            // Advisor_Form
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InactiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(button_Home);
            Controls.Add(textBox_Id);
            Controls.Add(Salary_textBox);
            Controls.Add(Designation_textBox);
            Controls.Add(label1);
            Cursor = Cursors.SizeNESW;
            ForeColor = SystemColors.ControlDarkDark;
            Name = "Advisor_Form";
            Text = "Advisor_Form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox Designation_textBox;
        private TextBox Salary_textBox;
        private TextBox textBox_Id;
        private Button button_Home;
    }
}