﻿namespace _2022_CS_195_ProjectA
{
    internal class Groups_button
    {
    }
}