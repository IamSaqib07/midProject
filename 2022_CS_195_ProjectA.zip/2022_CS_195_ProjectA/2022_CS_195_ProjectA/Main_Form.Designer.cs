﻿
namespace _2022_CS_195_ProjectA
{
    partial class Main_Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flowLayoutPanel_Left = new FlowLayoutPanel();
            DashBoard_Button = new Button();
            Project_button = new Button();
            Advisor_button = new Button();
            Groups_button = new Button();
            Student_button = new Button();
            panel_Top = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            flowLayoutPanel_Left.SuspendLayout();
            panel_Top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // flowLayoutPanel_Left
            // 
            flowLayoutPanel_Left.BackColor = SystemColors.ButtonShadow;
            flowLayoutPanel_Left.Controls.Add(DashBoard_Button);
            flowLayoutPanel_Left.Controls.Add(Project_button);
            flowLayoutPanel_Left.Controls.Add(Advisor_button);
            flowLayoutPanel_Left.Controls.Add(Groups_button);
            flowLayoutPanel_Left.Controls.Add(Student_button);
            flowLayoutPanel_Left.Location = new Point(0, 62);
            flowLayoutPanel_Left.Name = "flowLayoutPanel_Left";
            flowLayoutPanel_Left.Size = new Size(200, 389);
            flowLayoutPanel_Left.TabIndex = 0;
            // 
            // DashBoard_Button
            // 
            DashBoard_Button.BackColor = SystemColors.ControlLightLight;
            DashBoard_Button.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DashBoard_Button.Location = new Point(3, 3);
            DashBoard_Button.Name = "DashBoard_Button";
            DashBoard_Button.Size = new Size(197, 46);
            DashBoard_Button.TabIndex = 0;
            DashBoard_Button.Text = "DashBoard";
            DashBoard_Button.UseVisualStyleBackColor = false;
            // 
            // Project_button
            // 
            Project_button.BackColor = SystemColors.ControlLightLight;
            Project_button.Cursor = Cursors.SizeWE;
            Project_button.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Project_button.Location = new Point(3, 55);
            Project_button.Name = "Project_button";
            Project_button.Size = new Size(197, 52);
            Project_button.TabIndex = 1;
            Project_button.Text = "Project";
            Project_button.UseVisualStyleBackColor = false;
            Project_button.Click += Project_button_Click;
            // 
            // Advisor_button
            // 
            Advisor_button.BackColor = SystemColors.ControlLightLight;
            Advisor_button.Cursor = Cursors.SizeWE;
            Advisor_button.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Advisor_button.Location = new Point(3, 113);
            Advisor_button.Name = "Advisor_button";
            Advisor_button.Size = new Size(197, 52);
            Advisor_button.TabIndex = 2;
            Advisor_button.Text = "Advisor";
            Advisor_button.UseVisualStyleBackColor = false;
            Advisor_button.Click += Advisor_button_Click;
            // 
            // Groups_button
            // 
            Groups_button.BackColor = SystemColors.ControlLightLight;
            Groups_button.Cursor = Cursors.SizeWE;
            Groups_button.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Groups_button.Location = new Point(3, 171);
            Groups_button.Name = "Groups_button";
            Groups_button.Size = new Size(197, 52);
            Groups_button.TabIndex = 3;
            Groups_button.Text = "Groups";
            Groups_button.UseVisualStyleBackColor = false;
            Groups_button.Click += Groups_button_Click;
            // 
            // Student_button
            // 
            Student_button.BackColor = SystemColors.ControlLightLight;
            Student_button.Cursor = Cursors.SizeWE;
            Student_button.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Student_button.Location = new Point(3, 229);
            Student_button.Name = "Student_button";
            Student_button.Size = new Size(197, 52);
            Student_button.TabIndex = 4;
            Student_button.Text = "Student";
            Student_button.UseVisualStyleBackColor = false;
            Student_button.Click += Student_button_Click;
            // 
            // panel_Top
            // 
            panel_Top.BackColor = SystemColors.Info;
            panel_Top.Controls.Add(pictureBox1);
            panel_Top.Controls.Add(label1);
            panel_Top.Location = new Point(0, 1);
            panel_Top.Name = "panel_Top";
            panel_Top.Size = new Size(801, 63);
            panel_Top.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ButtonHighlight;
            pictureBox1.Image = Properties.Resources.icons8_menu_50;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(197, 55);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.GradientInactiveCaption;
            label1.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(282, 8);
            label1.Name = "label1";
            label1.Size = new Size(230, 50);
            label1.TabIndex = 0;
            label1.Text = "Mid-Project";
            // 
            // Main_Form
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.WindowFrame;
            ClientSize = new Size(800, 450);
            Controls.Add(panel_Top);
            Controls.Add(flowLayoutPanel_Left);
            Name = "Main_Form";
            Text = "Form1";
            Load += Form1_Load;
            flowLayoutPanel_Left.ResumeLayout(false);
            panel_Top.ResumeLayout(false);
            panel_Top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        private void Groups_button_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private FlowLayoutPanel flowLayoutPanel_Left;
        private Panel panel_Top;
        private Button DashBoard_Button;
        private Button Project_button;
        private Button Advisor_button;
        private Button Groups_button;
        private Button Student_button;
        private Label label1;
        private PictureBox pictureBox1;
    }
}
