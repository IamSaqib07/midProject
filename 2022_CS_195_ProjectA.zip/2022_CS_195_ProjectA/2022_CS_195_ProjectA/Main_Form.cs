namespace _2022_CS_195_ProjectA
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Student_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Student_Foam student_Foam = new Student_Foam();
            student_Foam.Show();
        }

        private void Advisor_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Advisor_Form advisor_Form = new Advisor_Form();
            advisor_Form.Show();
        }

        private void Project_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Projects_Form projects_Form = new Projects_Form();
            projects_Form.Show();
        }
    }
}
