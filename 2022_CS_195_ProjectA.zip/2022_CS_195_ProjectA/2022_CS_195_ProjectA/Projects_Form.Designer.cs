﻿namespace _2022_CS_195_ProjectA
{
    partial class Projects_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Projects_label = new Label();
            textBox_Id = new TextBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            button_Home = new Button();
            SuspendLayout();
            // 
            // Projects_label
            // 
            Projects_label.AutoSize = true;
            Projects_label.BackColor = SystemColors.ActiveCaptionText;
            Projects_label.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Projects_label.ForeColor = Color.Yellow;
            Projects_label.Location = new Point(250, 60);
            Projects_label.Name = "Projects_label";
            Projects_label.Size = new Size(257, 50);
            Projects_label.TabIndex = 1;
            Projects_label.Text = "Projects Page";
            // 
            // textBox_Id
            // 
            textBox_Id.BackColor = SystemColors.Info;
            textBox_Id.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Id.Location = new Point(82, 177);
            textBox_Id.Name = "textBox_Id";
            textBox_Id.Size = new Size(252, 29);
            textBox_Id.TabIndex = 4;
            textBox_Id.Text = "Id";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Info;
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(401, 177);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(252, 29);
            textBox1.TabIndex = 5;
            textBox1.Text = "Description";
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Info;
            textBox2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(250, 241);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(252, 29);
            textBox2.TabIndex = 6;
            textBox2.Text = "Title";
            // 
            // button_Home
            // 
            button_Home.BackColor = Color.Khaki;
            button_Home.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_Home.ForeColor = SystemColors.ActiveCaptionText;
            button_Home.Location = new Point(340, 350);
            button_Home.Name = "button_Home";
            button_Home.Size = new Size(75, 35);
            button_Home.TabIndex = 7;
            button_Home.Text = "Home";
            button_Home.UseVisualStyleBackColor = false;
            button_Home.Click += this.button_Home_Click;
            // 
            // Projects_Form
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(800, 450);
            Controls.Add(button_Home);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(textBox_Id);
            Controls.Add(Projects_label);
            Name = "Projects_Form";
            Text = "Projects_Form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Projects_label;
        private TextBox textBox_Id;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button_Home;
    }
}