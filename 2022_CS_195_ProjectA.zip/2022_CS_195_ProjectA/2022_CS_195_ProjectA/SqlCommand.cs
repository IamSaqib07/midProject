﻿
namespace _2022_CS_195_ProjectA
{
    internal class SqlCommand
    {
        private string insertQuery;
        private SqlConnection connection;

        public SqlCommand(string insertQuery, SqlConnection connection)
        {
            this.insertQuery = insertQuery;
            this.connection = connection;
        }

        public object Parameters { get; internal set; }

        internal void ExecuteNonQuery()
        {
            throw new NotImplementedException();
        }
    }
}