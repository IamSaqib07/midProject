﻿
namespace _2022_CS_195_ProjectA
{
    internal class SqlConnection
    {
        private string newstring;

        public SqlConnection(string newstring)
        {
            this.newstring = newstring;
        }

        internal void Close()
        {
            throw new NotImplementedException();
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}