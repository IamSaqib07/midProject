﻿
namespace _2022_CS_195_ProjectA
{
    partial class Student_Foam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            StudentPage_label = new Label();
            textBox_RegNo = new TextBox();
            textBox_Date_of_Birth = new TextBox();
            textBox_ContactNo = new TextBox();
            textBox_Email = new TextBox();
            button_Add = new Button();
            button_Update = new Button();
            button_Delete = new Button();
            button_Remove = new Button();
            textBox_FirstName = new TextBox();
            textBox_LastName = new TextBox();
            textBox_Category = new TextBox();
            textBox_Value = new TextBox();
            textBox_Gender = new TextBox();
            button_Home = new Button();
            SuspendLayout();
            // 
            // StudentPage_label
            // 
            StudentPage_label.AutoSize = true;
            StudentPage_label.BackColor = SystemColors.ActiveCaptionText;
            StudentPage_label.Font = new Font("Microsoft Sans Serif", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            StudentPage_label.ForeColor = Color.Yellow;
            StudentPage_label.Location = new Point(250, 36);
            StudentPage_label.Name = "StudentPage_label";
            StudentPage_label.Size = new Size(257, 42);
            StudentPage_label.TabIndex = 0;
            StudentPage_label.Text = "Student Page";
            // 
            // textBox_RegNo
            // 
            textBox_RegNo.BackColor = SystemColors.Info;
            textBox_RegNo.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_RegNo.Location = new Point(134, 118);
            textBox_RegNo.Name = "textBox_RegNo";
            textBox_RegNo.Size = new Size(191, 29);
            textBox_RegNo.TabIndex = 3;
            textBox_RegNo.Text = "Registration Number";
            textBox_RegNo.Enter += TextBox_RegNo_Enter;
            textBox_RegNo.Leave += TextBox_RegNo_Leave;
            // 
            // textBox_Date_of_Birth
            // 
            textBox_Date_of_Birth.BackColor = SystemColors.Info;
            textBox_Date_of_Birth.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Date_of_Birth.Location = new Point(134, 221);
            textBox_Date_of_Birth.Name = "textBox_Date_of_Birth";
            textBox_Date_of_Birth.Size = new Size(169, 29);
            textBox_Date_of_Birth.TabIndex = 4;
            textBox_Date_of_Birth.Text = "Date of Birth";
            textBox_Date_of_Birth.Enter += TextBox_Date_of_Birth_Enter;
            textBox_Date_of_Birth.Leave += TextBox_Date_of_Birth_Leave;
            // 
            // textBox_ContactNo
            // 
            textBox_ContactNo.BackColor = SystemColors.Info;
            textBox_ContactNo.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_ContactNo.Location = new Point(395, 221);
            textBox_ContactNo.Name = "textBox_ContactNo";
            textBox_ContactNo.Size = new Size(191, 29);
            textBox_ContactNo.TabIndex = 5;
            textBox_ContactNo.Text = "Contact";
            textBox_ContactNo.Enter += textBox_ContactNo_Enter;
            textBox_ContactNo.Leave += textBox_ContactNo_Leave;
            // 
            // textBox_Email
            // 
            textBox_Email.BackColor = SystemColors.Info;
            textBox_Email.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Email.Location = new Point(134, 312);
            textBox_Email.Name = "textBox_Email";
            textBox_Email.Size = new Size(358, 29);
            textBox_Email.TabIndex = 6;
            textBox_Email.Text = "Email";
            textBox_Email.Enter += textBox_Email_Enter;
            textBox_Email.Leave += textBox_Email_Leave;
            // 
            // button_Add
            // 
            button_Add.BackColor = SystemColors.InactiveCaption;
            button_Add.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            button_Add.Location = new Point(250, 361);
            button_Add.Name = "button_Add";
            button_Add.Size = new Size(75, 32);
            button_Add.TabIndex = 10;
            button_Add.Text = "Add";
            button_Add.UseVisualStyleBackColor = false;
            button_Add.Click += button_Add_Click;
            // 
            // button_Update
            // 
            button_Update.BackColor = SystemColors.InactiveCaption;
            button_Update.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_Update.Location = new Point(408, 361);
            button_Update.Name = "button_Update";
            button_Update.Size = new Size(75, 32);
            button_Update.TabIndex = 11;
            button_Update.Text = "Update";
            button_Update.UseVisualStyleBackColor = false;
            // 
            // button_Delete
            // 
            button_Delete.BackColor = SystemColors.InactiveCaption;
            button_Delete.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_Delete.Location = new Point(250, 408);
            button_Delete.Name = "button_Delete";
            button_Delete.Size = new Size(75, 30);
            button_Delete.TabIndex = 12;
            button_Delete.Text = "Delete";
            button_Delete.UseVisualStyleBackColor = false;
            // 
            // button_Remove
            // 
            button_Remove.BackColor = SystemColors.InactiveCaption;
            button_Remove.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_Remove.Location = new Point(408, 408);
            button_Remove.Name = "button_Remove";
            button_Remove.Size = new Size(75, 30);
            button_Remove.TabIndex = 13;
            button_Remove.Text = "Remove";
            button_Remove.UseVisualStyleBackColor = false;
            // 
            // textBox_FirstName
            // 
            textBox_FirstName.BackColor = SystemColors.Info;
            textBox_FirstName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_FirstName.Location = new Point(395, 118);
            textBox_FirstName.Name = "textBox_FirstName";
            textBox_FirstName.Size = new Size(169, 29);
            textBox_FirstName.TabIndex = 15;
            textBox_FirstName.Text = "First Name";
            textBox_FirstName.Enter += textBox_FirstName_Enter;
            textBox_FirstName.Leave += textBox_FirstName_Leave;
            // 
            // textBox_LastName
            // 
            textBox_LastName.BackColor = SystemColors.Info;
            textBox_LastName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_LastName.Location = new Point(395, 166);
            textBox_LastName.Name = "textBox_LastName";
            textBox_LastName.Size = new Size(169, 29);
            textBox_LastName.TabIndex = 16;
            textBox_LastName.Text = "Last Name";
            textBox_LastName.Enter += textBox_LastName_Enter;
            textBox_LastName.Leave += textBox_LastName_Leave;
            // 
            // textBox_Category
            // 
            textBox_Category.BackColor = SystemColors.Info;
            textBox_Category.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Category.Location = new Point(134, 266);
            textBox_Category.Name = "textBox_Category";
            textBox_Category.Size = new Size(191, 29);
            textBox_Category.TabIndex = 17;
            textBox_Category.Text = "Category";
            textBox_Category.Enter += textBox_Category_Enter;
            textBox_Category.Leave += textBox_Category_Leave;
            // 
            // textBox_Value
            // 
            textBox_Value.BackColor = SystemColors.Info;
            textBox_Value.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Value.Location = new Point(395, 266);
            textBox_Value.Name = "textBox_Value";
            textBox_Value.Size = new Size(191, 29);
            textBox_Value.TabIndex = 18;
            textBox_Value.Text = "Value";
            textBox_Value.Enter += textBox_Value_Enter;
            textBox_Value.Leave += textBox_Value_Leave;
            // 
            // textBox_Gender
            // 
            textBox_Gender.BackColor = SystemColors.Info;
            textBox_Gender.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox_Gender.Location = new Point(134, 166);
            textBox_Gender.Name = "textBox_Gender";
            textBox_Gender.Size = new Size(169, 29);
            textBox_Gender.TabIndex = 14;
            textBox_Gender.Text = "Gender";
            textBox_Gender.Enter += textBox_Gender_Enter_1;
            textBox_Gender.Leave += textBox_Gender_Leave;
            // 
            // button_Home
            // 
            button_Home.BackColor = Color.Khaki;
            button_Home.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_Home.ForeColor = SystemColors.ActiveCaptionText;
            button_Home.Location = new Point(644, 403);
            button_Home.Name = "button_Home";
            button_Home.Size = new Size(75, 35);
            button_Home.TabIndex = 19;
            button_Home.Text = "Home";
            button_Home.UseVisualStyleBackColor = false;
            button_Home.Click += button_Home_Click;
            // 
            // Student_Foam
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            ClientSize = new Size(800, 450);
            Controls.Add(button_Home);
            Controls.Add(textBox_Value);
            Controls.Add(textBox_Category);
            Controls.Add(textBox_LastName);
            Controls.Add(textBox_FirstName);
            Controls.Add(textBox_Gender);
            Controls.Add(button_Remove);
            Controls.Add(button_Delete);
            Controls.Add(button_Update);
            Controls.Add(button_Add);
            Controls.Add(textBox_Email);
            Controls.Add(textBox_ContactNo);
            Controls.Add(textBox_Date_of_Birth);
            Controls.Add(textBox_RegNo);
            Controls.Add(StudentPage_label);
            Name = "Student_Foam";
            Text = "Student_Form";
            Load += Student_Foam_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private void Student_Foam_Load(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void TextBox_id_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void textBox_id_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label StudentPage_label;
        private TextBox textBox_RegNo;
        private TextBox textBox_Date_of_Birth;
        private TextBox textBox_ContactNo;
        private TextBox textBox_Email;
        private Button button_Add;
        private Button button_Update;
        private Button button_Delete;
        private Button button_Remove;
        private TextBox textBox_FirstName;
        private TextBox textBox_LastName;
        private TextBox textBox_Category;
        private TextBox textBox_Value;
        private TextBox textBox_Gender;
        private Button button_Home;
    }
}