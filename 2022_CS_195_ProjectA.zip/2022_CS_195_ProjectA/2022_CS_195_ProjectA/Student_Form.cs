﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2022_CS_195_ProjectA
{
    public partial class Student_Foam : Form
    {
        public Student_Foam()
        {
            InitializeComponent();
        }

        private void TextBox_RegNo_Enter(object sender, EventArgs e)
        {
            if (textBox_RegNo.Text == "Registration Number")
            {
                textBox_RegNo.Text = "";
                textBox_RegNo.ForeColor = Color.Black;
            }
        }

        private void TextBox_RegNo_Leave(object sender, EventArgs e)
        {
            if (textBox_RegNo.Text == "")
            {
                textBox_RegNo.Text = "Registration Number";
                textBox_RegNo.ForeColor = Color.Gray;
            }
        }

        private void TextBox_Date_of_Birth_Enter(object sender, EventArgs e)
        {
            if (textBox_Date_of_Birth.Text == "Date of Birth")
            {
                textBox_Date_of_Birth.Text = "";
                textBox_Date_of_Birth.ForeColor = Color.Black;
            }
        }

        private void TextBox_Date_of_Birth_Leave(object sender, EventArgs e)
        {
            if (textBox_Date_of_Birth.Text == "")
            {
                textBox_Date_of_Birth.Text = "Date of Birth";
                textBox_Date_of_Birth.ForeColor = Color.Gray;
            }
        }

        private void textBox_ContactNo_Enter(object sender, EventArgs e)
        {
            if (textBox_ContactNo.Text == "Contact")
            {
                textBox_ContactNo.Text = "";
                textBox_ContactNo.ForeColor = Color.Black;
            }
        }

        private void textBox_ContactNo_Leave(object sender, EventArgs e)
        {
            if (textBox_ContactNo.Text == "")
            {
                textBox_ContactNo.Text = "Contact";
                textBox_ContactNo.ForeColor = Color.Gray;
            }
        }

        private void textBox_Email_Enter(object sender, EventArgs e)
        {
            if (textBox_Email.Text == "Email")
            {
                textBox_Email.Text = "";
                textBox_Email.ForeColor = Color.Black;
            }
        }

        private void textBox_Email_Leave(object sender, EventArgs e)
        {
            if (textBox_Email.Text == "")
            {
                textBox_Email.Text = "Email";
                textBox_Email.ForeColor = Color.Gray;
            }
        }

        private void textBox_Category_Enter(object sender, EventArgs e)
        {
            if (textBox_Category.Text == "Category")
            {
                textBox_Category.Text = "";
                textBox_Category.ForeColor = Color.Black;
            }
        }

        private void textBox_Category_Leave(object sender, EventArgs e)
        {
            if (textBox_Category.Text == "")
            {
                textBox_Category.Text = "Category";
                textBox_Category.ForeColor = Color.Gray;
            }
        }

        private void textBox_Value_Enter(object sender, EventArgs e)
        {
            if (textBox_Value.Text == "Value")
            {
                textBox_Value.Text = "";
                textBox_Value.ForeColor = Color.Black;
            }
        }

        private void textBox_Value_Leave(object sender, EventArgs e)
        {
            if (textBox_Value.Text == "")
            {
                textBox_Value.Text = "Value";
                textBox_Value.ForeColor = Color.Gray;
            }
        }

        private void textBox_Gender_Enter_1(object sender, EventArgs e)
        {
            if (textBox_Gender.Text == "Gender")
            {
                textBox_Gender.Text = "";
                textBox_Gender.ForeColor = Color.Black;
            }
        }

        private void textBox_Gender_Leave(object sender, EventArgs e)
        {
            if (textBox_Gender.Text == "")
            {
                textBox_Gender.Text = "Gender";
                textBox_Gender.ForeColor = Color.Gray;
            }
        }

        private void textBox_FirstName_Enter(object sender, EventArgs e)
        {
            if (textBox_FirstName.Text == "First Name")
            {
                textBox_FirstName.Text = "";
                textBox_FirstName.ForeColor = Color.Black;
            }
        }

        private void textBox_FirstName_Leave(object sender, EventArgs e)
        {
            if (textBox_FirstName.Text == "")
            {
                textBox_FirstName.Text = "First Name";
                textBox_FirstName.ForeColor = Color.Gray;
            }
        }

        private void textBox_LastName_Enter(object sender, EventArgs e)
        {
            if (textBox_LastName.Text == "Last Name")
            {
                textBox_LastName.Text = "";
                textBox_LastName.ForeColor = Color.Black;
            }
        }

        private void textBox_LastName_Leave(object sender, EventArgs e)
        {
            if (textBox_LastName.Text == "")
            {
                textBox_LastName.Text = "Last Name";
                textBox_LastName.ForeColor = Color.Gray;
            }
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            String newstring = @"Data Source=(local);Initial Catalog=ProjectA;Integrated Security=True";

            try
            {
                SqlConnection connection = new SqlConnection(newstring);


                connection.Open();
                string insertQuery = "INSERT INTO Lookup (Value, Category) VALUES (@Value, @Category)";

                SqlCommand command = new SqlCommand(insertQuery, connection);

               

                command.ExecuteNonQuery();
                connection.Close();

            }
            catch (Exception ex)
            {
                // Handle exceptions here, for example, logging the error or showing an error message to the user.
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_Home_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main_Form main_Form = new Main_Form();
            main_Form.Show();
        }
    }
}

